<?php
//add menu main
//OW::getNavigation()->addMenuItem(OW_Navigation::MAIN, 'yncontactimporter-import', 'yncontactimporter', 'contact_importer', OW_Navigation::VISIBLE_FOR_MEMBER);
//add widget

?>