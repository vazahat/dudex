<?php
//OW::getNavigation()->deleteMenuItem('ynsocialstream', 'ynsocialstream-global-settings');
//remove widget

?>